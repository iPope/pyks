#!/usr/bin/env python

from distutils.core import setup

setup(name='Pyks',
      version='0.0.7a',
      description='Python kilo-seconds manipulation module',
      author='Callum Booth',
      author_email='callumwbooth@gmail.com',
	  url='https://github.com/cbooth/pyks',
      package=['pyks']
     )
